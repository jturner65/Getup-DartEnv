#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun 15 12:37:19 2018

@author: john

"""

import numpy as np

from abc import ABC, abstractmethod


#class to hold trajectories to follow
class followTraj(ABC):
    """
    args is dictionary of arguments to define trajectory
    
    trajSpeed : speed of object - how far it moves per timestep
    trackObj : reference to tracked object
    dt : timestep
    humanSkelHldr : skel holder for human
    botSkelHldr : skel holder for robot
    
    """
    
    def __init__(self, args):
        self.trajSpeed = args['trajSpeed']
        self.trackObj = args['trackObj']
        self.dt = args['dt']
        self.humanSkelHldr = args['humanSkelHldr']
        self.botSkelHldr = args['botSkelHldr']
        #trajectory starting location
        self.stLoc = None
        
        self.trajStep = 0
        self.trajIncr = self.dt * self.trajSpeed
        self.debug = False
        #traj length multiplier -> used for setting location within trajectory.
        #circle traj is 2pi
        self.trajLenMultiplier = 1.0
        
    def setDebug(self, _debug):
        self.debug = _debug
    
    #initialize trajectory with new starting and ending location
    def initTraj(self, initLoc, endLoc):
        self.trajStep = 0
        #set start location of trajectory
        self.stLoc = np.copy(initLoc)
        self.oldLoc = np.copy(initLoc)
        #put ball at this location
        self.returnToStart()
        #set up initial trajectory constants and functional components
        self.initTrajPriv(endLoc)

    #return traj object to start location of trajectory if one exists
    def returnToStart(self):
        if (self.stLoc is not None):
            self._setBallPos(self.stLoc)
        else:
            print('\nfollowTraj::returnToStart : no stLoc set to return to.' )

    @abstractmethod
    def initTrajPriv(self,endLoc):
        pass
    
    #save current state of trajectory
    def saveCurVals(self):
        self.savedLoc = self.trackObj.com()
        self.savedOldLoc = np.copy(self.oldLoc)
        self.savedTrajStep = self.trajStep
        
    #restore a trajectory to previous saved state
    def restoreSavedVals(self):
        self.oldLoc = self.savedOldLoc
        spherePos = self._setBallPos(self.savedLoc)
        self.trajStep = self.savedTrajStep
    
    def advTrackedPosition(self, movVec):
        #verifies whether or not the object is moved outside of this trajectory class (i.e. via sim)
        oldLoc = self.trackObj.com()
        newLoc, doneTraj = self.getNewTrackedPosition(movVec)  
        spherePos = self._setBallPos(newLoc)
        if(self.debug):
            print('\n')
            if(not np.allclose(self.oldLoc, oldLoc, 1e-10)):
                print('!!!!followTraj::advTrackedPosition : Tracked Obj moved by simulation interactions : expected old loc : {}|\t actual old loc : {}'.format(self.oldLoc,oldLoc))
            print('followTraj::advTrackedPosition : Tracked Obj COM after Update : {}|\told loc : {}|\tnewLoc used to update :{} with dt = {} \n'.format(self.trackObj.com(),oldLoc,newLoc,self.trajStep))
    
        #save current location as next step's old location, to verify that this functionality is only component responsible for ball displacement
        self.oldLoc = np.copy(newLoc)
        #returns whether we are at end of trajectory or not
        return doneTraj
    
    #move to some percentage of the full trajectory (a single circle for circular trajs)
    def setTrackedPosition(self, d, movVec):
        if d < 0 : 
            d = 0
        if d > 1 : 
            d = 1        
        self.trajStep = d * self.trajLenMultiplier
        #move to new trajStep location
        return self.advTrackedPosition(movVec)
    
    #move object along
    @abstractmethod
    def getNewTrackedPosition(self,movVec):
        pass

    #set constraint/tracked ball's position to be newPos
    def _setBallPos(self, newPos):
        spherePos = np.copy(self.trackObj.q)
        #v = np.copy(self.trackObj.dq)
        spherePos[3:6] = newPos
        self.trackObj.set_positions(spherePos) 
        #self.trackObj.set_velocities(v)
        return spherePos        
    
    #############################################################
    #   the following static functions will build an equation that will fit a list of points, and evaulate that equation

    #will return array of deg+1 (rows) x 3 cols of coefficients of polynomial to fit points in ptsAra
    #ptsAra is list of 3d points
    @staticmethod
    def buildEqFromPts(ptsAra, deg):
        numPts = len(ptsAra)
        #take transpose of np matrix of points
        ptsTrans = np.transpose(np.array(ptsAra))
        #ptsTrans is 3 x numpoints
        t = np.linspace(0.0, 1.0, num=numPts)
        coeffsPerDim = []
        for i in range(len(ptsTrans)):
            coeffsPerDim.append(np.polyfit(t, ptsTrans[i], deg))      
        coeffs = np.transpose(np.array(coeffsPerDim))
        return coeffs


    #returns a solution to the polynomial parameterized equation at t given by coeffs
    #where coeffs is deg+1(rows) x 3 array of coefficients for deg polynomial
    @staticmethod
    def solvePolyFromCoeffs(coeffs, t):
        calcVal = np.array([0.0,0.0,0.0])
        numCoeffs = len(coeffs)
        #solve polynomial
        for i in range (numCoeffs - 1):
            calcVal += coeffs[i] * t
        #don't forget constant term       
        calcVal += coeffs[-1]
        return calcVal        


#circular trajectory   
class circleTraj(followTraj):
    def __init__(self, args):
        followTraj.__init__(self, args)
        #planar ellipse tilted ccw by tiltRad
        xRad = args['xRad']
        yRad = args['yRad']
        tiltRad = args['tiltRad']
        self.ballXradCtilt = xRad * np.cos(tiltRad)
        self.ballXradStilt = xRad * np.sin(tiltRad)
        self.ballYradCtilt = yRad * np.cos(tiltRad)
        self.ballYradStilt = yRad * np.sin(tiltRad) 
        #traj length multiplier -> used for setting location within trajectory.
        #circle traj is 2pi
        self.trajLenMultiplier = 2.0 * np.pi

    #endLoc is ignored
    def initTrajPriv(self,endLoc):
        #base center on current location and vectors of x and y radius
        ctrOffset = np.array([self.ballXradCtilt, self.ballXradStilt, 0])
        self.ballTrajCtr = self.trackObj.com() + ctrOffset
        #start and end at same location
        self.endLoc = np.copy(self.stLoc)
        
        if(self.debug):
            ballPos = self.ballTrajCtr - ctrOffset
            print('Tracking Ball location in initTracking : {} | calc pos : {}\n'.format(self.trackObj.com(), ballPos))
        
    def getNewTrackedPosition(self,movVec):
        cts = np.cos(self.trajStep)
        sts = np.sin(self.trajStep) 
        #evolve trajStep
        self.trajStep -= self.trajIncr
        #circle has no end, always false for end of trajectory
        return self.ballTrajCtr - np.array([(self.ballXradCtilt * cts - self.ballYradStilt * sts), (self.ballYradCtilt * sts + self.ballXradStilt * cts), 0]),False    
    
#linear trajectory        
class linearTraj(followTraj):
    def __init__(self, args):
        followTraj.__init__(self, args)
        #line through origin and relPoint2 of passed length, with origin displaced to self.stLoc 
        self.length = args['length']
        self.dirVec = args['rel2ndPt'] / np.linalg.norm(args['rel2ndPt'])
        
    #nothing special to init this trajectory
    #endloc is relative to stloc
    def initTrajPriv(self,endLoc):
        self.dirVec = endLoc / np.linalg.norm(endLoc)
        self.moveVec = self.dirVec * self.length
        self.endLoc = self.stLoc + self.moveVec        
    
    def getNewTrackedPosition(self,movVec): 
        #ratio of movVec length to length of trajectory is multiplier of trajIncr
        frcMultMag = np.linalg.norm(movVec)
        unitMovVec = movVec/frcMultMag
        stepIncr = self.trajIncr * (frcMultMag/self.length)

        loc = self.oldLoc + (stepIncr * unitMovVec)
        #loc = self.stLoc + (self.trajStep * self.moveVec)
        #evolve trajstep
        self.trajStep += stepIncr
        #line is done when we've moved length along dirvec
        return loc,(self.trajStep >= 1.0)
    
#parabolic trajectory        
class parabolicTraj(followTraj):
    def __init__(self, args):
        followTraj.__init__(self, args)
    #endloc is ignored
    def initTrajPriv(self,endLoc):
        print('parabolicTraj.initTrajPriv : Not Implemented')
    
    def getNewTrackedPosition(self,movVec):
        print('parabolicTraj.getNewTrackedPosition : Not Implemented')      
        #evolve trajstep
        self.trajStep += self.trajIncr
       
        return self.trackObj.com()
    
##trajectory specified by equation
#class eqTraj(followTraj):
#    def _init_ (self, args):
#        followTraj.__init__(self, args)
#        pts = args['trajPoints']
#        numPts = len(pts)
#        t=np.linspace(0,1.0,num=numPts, endpoint=True)
#        x=np.array([p[0] for p in pts ])
#        y=np.array([p[1] for p in pts ])
#        z=np.array([p[2] for p in pts ])
#        xeq = 

        