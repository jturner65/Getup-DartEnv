#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# # Modified version of dart_env.py to support 2 skeletons

import os

#from gym import error, spaces
from gym import error
import gym.spaces
from gym.utils import seeding
import numpy as np
#from os import path
import gym
import six

#these need to be added (at least temporarily) to path
import sys
sys.path.insert(0, os.path.expanduser( '~/dart-env/gym/envs/dart'))
from contactInfo import contactInfo
from skelHolders import *
from followTraj import *


from collections import defaultdict

from gym.envs.dart.static_window import *

try:
    import pydart2 as pydart
    from pydart2.gui.trackball import Trackball
    pydart.init()
except ImportError as e:
    raise error.DependencyNotInstalled("{}. (HINT: you need to install pydart2.)".format(e))

class DartEnv2Bot(gym.Env):
    #static variable holding what reward components we are using
    #must be some combination of implemented reward components : ['GAE_getUp','eefDist','action','height','footMovDist','lFootMovDist','rFootMovDist','comcop','contacts','UP_COMVEL','X_COMVEL','Z_COMVEL']
    #note, contacts not finished yet
    #all used to test rwd components
    #rwdCompsUsed = ['eefDist','action','height','footMovDist','lFootMovDist','rFootMovDist','comcop','contacts','UP_COMVEL','X_COMVEL','Z_COMVEL']
    #rwdCompsUsed = ['eefDist','action','height','lFootMovDist','rFootMovDist','comcop','UP_COMVEL','X_COMVEL','Z_COMVEL']
    #rwdCompsUsed = ['eefDist','action','height','lFootMovDist','rFootMovDist','UP_COMVEL','comcop']
    #rwdCompsUsed = ['action','height','lFootMovDist','rFootMovDist','UP_COMVEL','comcop']
    #rwdCompsUsed = ['eefDist','action','height','lFootMovDist','rFootMovDist']
    #rwdCompsUsed = ['eefDist','action','contacts','height','lFootMovDist','rFootMovDist']
    #rwdCompsUsed = ['eefDist','action','height']
    #rwdCompsUsed = ['eefDist','action','comcop']
    #rwdCompsUsed = ['action','height']
    rwdCompsUsed = ['GAE_getUp']
    
    
    """Superclass for dart environment with 2 bots contained in one skel file
    
        From gym.Env : 
    'The main API methods that users of this class need to know are:

        step
        reset
        render
        close
        seed

#    When implementing an environment, override the following methods
#    in your subclass - these have been DEPRECATED
#
#        _step 
#        _reset 
#        _render
#        _close
#        _seed

    And set the following attributes:

        action_space: The Space object corresponding to valid actions
        observation_space: The Space object corresponding to valid observations
        reward_range: A tuple corresponding to the min and max possible rewards '   
            
    """

    def __init__(self, model_paths, frame_skip,  dt=0.002, obs_type="parameter", 
                action_type="continuous", visualize=True, disableViewer=False,
                screen_width=80, screen_height=45):
        assert obs_type in ('parameter', 'image')
        assert action_type in ("continuous", "discrete")
        print('pydart initialization OK')
        self.viewer = None

        # if len(model_paths) < 1:
        #     raise StandardError("At least one model file is needed.")

        if isinstance(model_paths, str):
            model_paths = [model_paths]
        #keep around so we can inspect trained policy environments, to see what skel files they used for training
        self.mode_paths = model_paths    
        #list of all skelHolders - convenience class holding all relevant info about a skeleton
        self.skelHldrs = {}
        #save and restore world state
        self.tot_SimState = []
        self.stateSaved = False

        #load skels, make world
        self.loadAllSkels(model_paths, dt)  
        #init RL-related vars from ctor
        self._obs_type = obs_type
        self.frame_skip = frame_skip
        self.visualize = visualize  #Show the window or not
        self.disableViewer = disableViewer

        #build list of slkeleton handlers
        self._buildSkelHndlrs(model_paths)
        #set random seed - NEED TO USE TRPO TRAINING SEED IF EXISTS
        self.seed()
        #set far-away center point for contact torque calculation to derive COP point from contacts with ground
        self.ctrTauPt = np.array([500,0,500])


        #set which skeleton is active for RL, which also sets action and observation space
        self.setActiveRLSkelHndlr(self.humanIdx)

        #set perturbations if used
        self.setPerturbation(False)

        # initialize the viewer, get the window size
        # initial here instead of in _render in image learning
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.viewer = None
        self._get_viewer()
        
        #number of broken sim runs for this instance
        self.numBrokeSims = 0

        #overriding env stuff
        self.metadata = {
            'render.modes': ['human', 'rgb_array'],
            'video.frames_per_second' : int(np.round(1.0 / self.dt))
        }
            
    @staticmethod
    def getRwdsToUseBin(listOfRwds):
        binDig = 0
        #build binary digit used to determine which reward components are used for this simulation
        for rwd in listOfRwds :
            try :
                idx = ANASkelHolder.rwdNames.index(rwd)
                binDig = binDig | (2**idx)
            except :
                print('!!!!!!!! dart_env_2bot::setRwdsToUse : ERROR : rwd type {} not found in implemented lists of reward components : \n{}'.format(rwd,ANASkelHolder.rwdNames)) 
                pass
        strVal = '{0:0{1}b}'.format(binDig, len(ANASkelHolder.rwdNames))
        return strVal
    
    #build a list of reward names given an int (binDig) which represents bit flags for each reward component
    @staticmethod
    def bldRwdListFromBinDig(binDig):
        rwdList = []
        for x in range(len(ANASkelHolder.rwdNames)):
            if (binDig & 2**x) > 0  : 
                rwdList.append(ANASkelHolder.rwdNames[x])
        return rwdList

    #static variable - binary rep of lists of reward components, calls static method 
    binStrRepRwdDigs = getRwdsToUseBin.__func__(rwdCompsUsed)

    #make trajectory to follow
    #args is dictionary of arguments
    def trackTrajFactory(self, trajTyp):
        traj = None
        #arguments shared with all trajectories
        args={}
        args['trajSpeed'] = .6
        args['trackObj'] = self.grabLink
        args['dt'] = self.dart_world.dt
        args['humanSkelHldr'] = self.skelHldrs[self.humanIdx]
        args['botSkelHldr'] = self.skelHldrs[self.botIdx]
        
        if ('circle' in trajTyp.lower()):
            #add circular values here
            #x radius, y radius, tilt above horizontal
            args['xRad'] = .30
            args['yRad'] = .10
            args['tiltRad'] = np.pi/5.0
            return circleTraj(args)
            
        elif ('linear' in trajTyp.lower()):
            #add linear values to args here
            #TODO make able to handle end point
            #args['endPoint'] = np.array([.5,1.1,0])
            #2nd point relative to start loc of traj
            args['rel2ndPt']=np.array([.5,1.1,0])
            #trajectory length in meters
            args['length']=1.0
            return linearTraj(args)
            
        elif ('parabola' in trajTyp.lower()):
            #add parabolic values to args here
            #TODO
            return parabolicTraj(args)

        else:
            print('Unknown Trajectory Type : {}'.format(trajTyp))
            return None      
        
    #get current state of sim world and all skeletons so it can be reset
    def saveSimState(self):
        self.tot_SimState = self.dart_world.states()
        self.stateSaved = True
        
    #restore sim state in world
    def restoreSimState(self):
        if(self.stateSaved):
            self.dart_world.set_states(self.tot_SimState)
            self.stateSaved = False
    
    #set which skeleton we are currently using for training/RL
    #also sets action and observation variables necessary for env to work
    def setActiveRLSkelHndlr(self, activeSkelIDX):
        self.actRL_SKHndlrIDX = activeSkelIDX           
        self.activeRL_SkelHndlr = self.skelHldrs[self.actRL_SKHndlrIDX]
        #execute this to update the observation and action space dimensions if they change
        #either because active skeleton handler has changed, or because dimension of assist
        #force has changed
        self.updateObsActSpaces()
        
    def updateObsActSpaces(self):
        #these are used externally
        self.obs_dim = self.activeRL_SkelHndlr.obs_dim
        self.act_dim = self.activeRL_SkelHndlr.action_dim
        self.action_space = self.activeRL_SkelHndlr.action_space
        self.observation_space = self.activeRL_SkelHndlr.observation_space

    #FOR DEBUGGING PURPOSES - generate a random observation of the activeRL_SkelHndlr
    def getRandomObservation(self):
        return self.activeRL_SkelHndlr.getRandomObservation()
     
    #3/16/18 problem is with skeleton
    #need to set skeleton joint stiffness and damping, and body friction
    #maybe even coulomb friction for joints.
    #set for every joint except world joint - joint limits, stiffness, damping
    #print('Set Joints for Skel {}'.format(skel.name))
    def _fixJointVals(self, skel, kd=10.0, ks=0.0):
        for jidx in range(skel.njoints):
            j = skel.joint(jidx)
            #don't mess with free joints
            if ('Free' in str(j)):
                continue
            nDof = j.num_dofs()
            for didx in range(nDof):
                if j.has_position_limit(didx):
                    j.set_position_limit_enforced(True)             
                
                j.set_damping_coefficient(didx, kd)
                j.set_spring_stiffness(didx, ks)
        
    #init either human or robot skeleton
    def _initLoadedSkel(self, skel, widx, skelType):       
        
        #eventually check for # dofs in skel to determine init
        stIDX = 0       
        if(skel.ndofs==9):#2D full body
            stIDX = 3
        elif(skel.ndofs==37):#3D full body
            stIDX = 6
        elif(skel.ndofs==29):#3d kima skel
            stIDX = 6

        #fixed robot arm has no fixed world dofs
        numActDofs = skel.ndofs - stIDX
        print('Skel : {} has {} dofs and {} act dofs'.format(skel.name,skel.ndofs, numActDofs))
        if('Human' in skelType):
            self._fixJointVals(skel, kd=10.0, ks=0.0)
            skelH = humanSkelHolder(self, skel, widx, stIDX, np.array([0,-.1319,0]))  
            bodyNamesAra = [['h_heel_left','h_toe_left'],['h_heel_right','h_toe_right'], ['h_hand_left','h_hand_right'], 'h_head']
        
        elif('Kima' in skelType):
            #used to modify kima's ks values when we used non-zero values - can be removed for ks==0
            if hasattr(self, 'kimaANAks'):
                ksVal = self.kimaANAks#set up to be non-0 in instancing class before this ctor is called if used
            else :
                ksVal = 0
            print('{}-type Kima is using ks val : {}'.format(skelType.lower(),ksVal))
            self._fixJointVals(skel, kd=10.0, ks=ksVal)
            isKimaNew = ('new' in skelType.lower())

            skelH = kimaHumanSkelHolder(self, skel, widx, stIDX, np.array([0,-0.35375,0]), isKimaNew)  
            bodyNamesAra = [['l-foot'],['r-foot'], ['l-lowerarm','r-lowerarm'], 'head']

        elif('Bot_Arm' in skelType):
            self._fixJointVals(skel, kd=0.0, ks=0.0)
            skelH = robotArmSkelHolder(self, skel, widx, stIDX, np.array([.05,0,0]))  
            #turn off collisions - NOTE This is for debugging only
            print('!!!!! NOTE : robot arm has no collisions enabled')
            self._setSkelCollidable(skel, False)
            bodyNamesAra = []

        elif('Robot' in skelType):
            self._fixJointVals(skel, kd=10.0, ks=0.0)
            skelH = robotSkelHolder(self, skel, widx,stIDX, np.array([0,-.1319,0]))
            bodyNamesAra = [['h_heel_left','h_toe_left'],['h_heel_right','h_toe_right'], ['h_hand_left','h_hand_right'], 'h_head']

        else :
            print('DartEnv2Bot::_initLoadedSkel : Unknown skel type based on given skeltype {} for skel {}'.format(skelType,skel.name))
            return None  
        #give skeleton reference to its key in skels dictionary
        skelH.setInitialSkelParams(bodyNamesAra, skelType)

        return skelH
        
    #set all body nodes in passed skel to allow or not allow collision
    def _setSkelCollidable(self, skel, canCollide):
        for body in skel.bodynodes:
            body.set_collidable(canCollide)
        
    #get skeleton objects from list in dart_world  
    def _buildSkelHndlrs(self, model_paths):
        numBots = self.dart_world.num_skeletons()
        self.hasHelperBot=False
        self.grabLink = None
        #apparently according to post on the subject in github from mxgrey, dart defaults to mu==100
        self.groundFric = 100.0
        
        for idx in range(numBots):
            saveSkel = False
            skelType = ''
            skel = self.dart_world.skeletons[idx]
            skelName = skel.name
            print('\nskelname : {}'.format(skelName))
            #this is humanoid to be helped up
            if ('getUpHumanoid' in skelName) or ('biped' in skelName) :
                skelType = 'Human'
                self.humanIdx = skelType
                #track getup humanoid in rendering
                #self.track_skeleton_id = idx
                saveSkel = True
            elif ('getUpHuman_Kima' in skelName) : 
                if ('old') in model_paths[1] :
                    skelType = 'KimaOld'
                else:
                    skelType = 'KimaNew'
                print('Using Kima Skel File version : {}'.format(skelType))
                self.humanIdx = skelType
                #track getup humanoid in rendering
                #self.track_skeleton_id = idx
                saveSkel = True                
            elif 'sphere_skel' in skelName :
                self.grabLink = skel
                skelType = 'Sphere'
                #print('sphere_skel : {} | {}'.format(self.grabLink.com(),self.grabLink.q))
                self.grabLink.bodynodes[0].set_collidable(False)
                #explicitly set this to not simulate
                self.grabLink.set_mobile(False)
                #force to counteract gravity
                self.sphereForce = np.array([0,9.8,0]) * self.grabLink.mass()
            elif 'box_skel' in skelName : 
                skelType = 'Bot Arm Support Box'
                #set to non-collidable to speed up training
                #print('Box is set to nonCollisions (for testing only)')
                #skel.bodynodes[0].set_collidable(False)
                skel.set_mobile(False)


            elif 'ground' in skelName : 
                skelType = 'Ground'
                #ground skeleton - set friction TODO verify
                #skel.friction = self.groundFric
                
            #Only have 1 type of helper bot
            elif 'helperBot' in skelName :
                skelType = 'Robot'
                self.botIdx = skelType
                saveSkel = True
                self.hasHelperBot=True
                #track helper bot
                self.track_skeleton_id = idx
                
                #if helper arm being built
            elif 'helperArm' in skelName :
                #fixed arm skeleton - build?
                skelType = 'Bot_Arm'
                self.botIdx = skelType
                saveSkel = True
                self.hasHelperBot=True
                #track helper bot
                self.track_skeleton_id = idx
                
                #using pre-built helper arm
            elif 'KR5sixxR650WP_description' in skelName :
                #fixed arm skeleton - build?
                skelType = 'KR5_Bot_Arm'
                self.botIdx = skelType
                saveSkel = True
                #track helper bot
                self.track_skeleton_id = idx
                self.hasHelperBot=True

                
            else :
                print('Skel Unknown : {}'.format(skelName))
                
            skel.friction = self.groundFric

            if saveSkel :
                #self.skelHldrs.append(self._initLoadedSkel(skel, idx, skelType, idxSkelHldrs))
                self.skelHldrs[skelType]= self._initLoadedSkel(skel, idx, skelType)
                saveSkel = False

        
            print('{} index : {} #dofs {} #nodes {} initial root loc : {}'.format(skelType,idx, skel.ndofs, skel.nbodies, skel.positions()[:6]))
        #give robot a ref to human skel handler if robot is there
        if (self.hasHelperBot):
            self.skelHldrs[self.botIdx].setHelpedSkelH(self.skelHldrs[self.humanIdx])
        print('dart_env_2bot::_buildSkelHndlrs finished\n\n')

    #return jacobians of either robot or human contact point
    #for debugging purposes to examine jacboian
    def getOptVars(self, useRobot=True):
        if(useRobot):
            skelhldr = self.skelHldrs[self.botIdx]
        else:
            skelhldr = self.skelHldrs[self.humanIdx]
        
        return skelhldr.getOptVars()
    

    # methods to override:
    # ----------------------------
    def reset_model(self):
        """
        Reset the robot degrees of freedom (qpos and qvel).
        Implement this in each subclass.
        """
        raise NotImplementedError

    def viewer_setup(self):
        """
        This method is called when the viewer is initialized and after every reset
        Optionally implement this method, if you need to tinker with camera position
        and so forth.
        """
        pass

    # -----------------------------
    def set_state(self, qpos, qvel):
        self.activeRL_SkelHndlr.set_state(qpos, qvel)

    def set_state_vector(self, state):
        self.activeRL_SkelHndlr.set_state_vector(state)        
        
    def state_vector(self):
        return self.activeRL_SkelHndlr.state_vector()


    @property
    def dt(self):
        return self.dart_world.dt * self.frame_skip
    
    def checkWorldStep(self, fr):
        #check to see if sim is broken each frame, if so, return with broken flag, frame # when broken, and skel causing break
        for k,v in self.skelHldrs.items():
            brk, chkSt, reason = v.checkSimIsBroken()
            if(brk):  #means sim is broken, end fwd sim, return which skel holder was broken                
                return True, {'broken':True, 'frame':fr, 'skelhndlr':v.name, 'reason':reason, 'skelState':chkSt}
        return False, {'broken':False, 'frame':fr, 'skelhndlr':'None', 'reason':'FINE', 'skelState':chkSt}
        

    ##NOT CURRENTLY USED - STEPPING world IN INSTANCED CLASS
    # need to perform on all skeletons that are being simulated
    def do_simulation(self, n_frames):
        if self.add_perturbation:
            self.checkPerturb()
            #apply their respective torques to all skeletons
            for fr in range(n_frames):
                for k,v in self.skelHldrs.items():
                    v.add_perturbation( self.perturbation_parameters[2], self.perturb_force)  
                    #tau is set in calling step routine
                    v.applyTau()                      
                self.dart_world.step()
    #            #check to see if sim is broken each frame, if so, return with broken flag, frame # when broken, and skel causing break
                chk,resDict = self.checkWorldStep(fr)
                #if chk break sim loop early and return dictionary of info
                if(chk):
                    return resDict        
        else :
            #apply their respective torques to all skeletons
            for fr in range(n_frames):
                for k,v in self.skelHldrs.items():
                    #tau is set in calling step routine
                    v.applyTau()                      
                self.dart_world.step()
    #            #check to see if sim is broken each frame, if so, return with broken flag, frame # when broken, and skel causing break
                chk,resDict = self.checkWorldStep(fr)
                #if chk break sim loop early and return dictionary of info
                if(chk):
                    return resDict
        #return default resdict if nothing broke     
        return resDict                   
            
            
    def checkPerturb(self):
        if self.perturbation_duration == 0:
            self.perturb_force *= 0
            if np.random.random() < self.perturbation_parameters[0]:
                axis_rand = np.random.randint(0, 2, 1)[0]
                direction_rand = np.random.randint(0, 2, 1)[0] * 2 - 1
                self.perturb_force[axis_rand] = direction_rand * self.perturbation_parameters[1]

        else:
            self.perturbation_duration -= 1
          
            
    #return a dictionary arranged by skeleton, of 1 dictionary per body of contact info
    #the same contact might be referenced multiple times
    def getContactInfo(self):
        contacts = self.dart_world.collision_result.contacts
        #dictionary of skeleton name-keyed body node collisions
        cntInfoDict = {}
        for i in range(len(self.dart_world.skeletons)):
            cntInfoDict[self.dart_world.skeletons[i].name] = defaultdict(contactInfo)
        
        for contact in contacts:
            cntInfoDict[contact.bodynode1.skeleton.name][contact.bodynode1.name].addContact(contact,contact.bodynode1,contact.bodynode2, self.ctrTauPt)
            cntInfoDict[contact.bodynode2.skeleton.name][contact.bodynode2.name].addContact(contact,contact.bodynode2,contact.bodynode1, self.ctrTauPt)
            
        return cntInfoDict

            
    ######################       
    #rendering stuff
    
    def close(self):
        if self.viewer is not None:
            self._get_viewer().close()
            self.viewer = None
        return
        
    #gym deprecated _<method name> methods so these act as wrappers    
    def seed(self, seed=None):
        """Sets the seed for this env's random number generator(s).

        Note:
            Some environments use multiple pseudorandom number generators.
            We want to capture all such seeds used in order to ensure that
            there aren't accidental correlations between multiple generators.

        Returns:
            list<bigint>: Returns the list of seeds used in this env's random
              number generators. The first value in the list should be the
              "main" seed, or the value which a reproducer should pass to
              'seed'. Often, the main seed equals the provided 'seed', but
              this won't be true if seed=None, for example.
        """
        self.np_random, seed = seeding.np_random(seed)
        return [seed]

    #_render deprecated in new gym code
    def render(self, mode='human', close=False):
        return self._render(mode)

    def reset(self):
        self.perturbation_duration = 0
        ob = self.reset_model()
        return ob
    

    def _seed(self, seed=None):
        self.np_random, seed = seeding.np_random(seed)
        return [seed]

    
      
    def _render(self, mode='human', close=False):
        if not self.disableViewer:
            self._get_viewer().scene.tb.trans[0] = -self.dart_world.skeletons[self.track_skeleton_id].com()[0]*1
        if close:
            if self.viewer is not None:
                self._get_viewer().close()
                self.viewer = None
            return

        if mode == 'rgb_array':
            data = self._get_viewer().getFrame()
            return data
        elif mode == 'human':
            self._get_viewer().runSingleStep()
            
    def getScreenRes(self):
        import subprocess
        output = subprocess.Popen('xrandr | grep "\*" | cut -d" " -f4',shell=True, stdout=subprocess.PIPE).communicate()[0]
        resolution = output.split()[0].split(b'x')
        return int(resolution[0]), int(resolution[1])
    
    def getViewer(self, sim, title=None):
        # glutInit(sys.argv)
        #get screen res, set window to be 85% of screen res, or 1280/720, whichever is larger
        scr_width, scr_height = self.getScreenRes()
        w=scr_width*.85
        h=scr_height *.85
        width = w if w > 1280 else 1280
        height = h if h > 720 else 720
        win = StaticGLUTWindow(sim, title, int(width), int(height))
        win.scene.add_camera(Trackball(theta=-45.0, phi = 0.0, zoom=0.1), 'gym_camera')
        win.resizeGL(200,100)
        win.scene.set_camera(win.scene.num_cameras()-1)

        # to add speed,
        if self._obs_type == 'image':
            win.run(self.screen_width, self.screen_height, _show_window=self.visualize)
        else:
            win.run(_show_window=self.visualize)
            
        return win

    def _get_viewer(self):
        if self.viewer is None and not self.disableViewer:
            self.viewer = self.getViewer(self.dart_world, 'Get Up!')
            self.viewer_setup()
        return self.viewer
    
        #disable/enable viewer
    def setViewerDisabled(self, vwrDisabled):
         self.disableViewer = vwrDisabled


    ####################
    # "private" methods
#    def _reset(self):
#        self.perturbation_duration = 0
#        ob = self.reset_model()
#        return ob

    #load all seletons and sim world
    def loadAllSkels(self, model_paths, dt):
        # convert everything to fullpath
        full_paths = []
        skelFullPath = None
        for model_path in model_paths:
            if model_path.startswith("/"):
                fullpath = model_path
            else:
                fullpath = os.path.join(os.path.dirname(__file__), "assets", model_path)
            if not os.path.exists(fullpath):
                raise IOError("File %s does not exist"%fullpath)
            
            if('.skel' in fullpath):
                if(skelFullPath is None):
                    skelFullPath = fullpath
                else:
                    print('Issue : multiple .skel files : {}\n\tand {}\n\tloadAllSkels only currently handles a single skel.  Subsequent skels are ignored'.format(fullpath,skelFullPath))
            else:
                full_paths.append(fullpath)
               
               
        if(skelFullPath is not None):
            #a .skel file exists
            self.dart_world = pydart.World(dt, skelFullPath)
        else :
            self.dart_world = pydart.World(dt)
        for fullpath in full_paths:
            self.dart_world.add_skeleton(fullpath)

        # try:
        #     self.dart_world.set_collision_detector(3)
        # except Exception as e:
        #     print('Does not have ODE collision detector, reverted to bullet collision detector')
        #     self.dart_world.set_collision_detector(2)

    #set perturbation if used
    #params : probability, magnitude, bodyid
    #dur : duration of perturbation in frames
    #frc : perturbation force
    def setPerturbation(self, isPerturb, params=[0.05, 5, 2], dur=40, frc=np.array([0,0,0])):
        # random perturbation
        self.add_perturbation = isPerturb
        self.perturbation_parameters = params 
        self.perturbation_duration = dur
        self.perturb_force = frc
            
   
#bodies in kima 
#[[BodyNode(0): pelvis_aux],
# [BodyNode(1): pelvis],
# [BodyNode(2): l-upperleg],
# [BodyNode(3): l-lowerleg],
# [BodyNode(4): l-foot],
# [BodyNode(5): r-upperleg],
# [BodyNode(6): r-lowerleg],
# [BodyNode(7): r-foot],
# [BodyNode(8): abdomen],
# [BodyNode(9): thorax],
# [BodyNode(10): head],
# [BodyNode(11): l-clavicle],
# [BodyNode(12): l-upperarm],
# [BodyNode(13): l-lowerarm],
# [BodyNode(14): r-clavicle],
# [BodyNode(15): r-upperarm],
# [BodyNode(16): r-lowerarm],
# [BodyNode(17): r-attachment]]

    
#root orientation 0,1,2
#root location 3,4,5

#left upper leg 6,7,8
#left shin, left heel(2) 9,10,11
#right thigh 12,13,14
#right shin, right heel(2) 15,16,17
#abdoment(2), spine 18, 19, 20
#bicep left(3) 21,22,23
#forearm left  24
#bicep right (3) 25, 26, 27
#forearm right 28    
        
#joints in kima -OLD KIMA
#[[TranslationalJoint(0): j_pelvis],
# [EulerJoint(1): j_pelvis2],
# [EulerJoint(2): j_thigh_left],
# [RevoluteJoint(3): j_shin_left],
# [UniversalJoint(4): j_heel_left],
# [EulerJoint(5): j_thigh_right],
# [RevoluteJoint(6): j_shin_right],
# [UniversalJoint(7): j_heel_right],
# [UniversalJoint(8): j_abdomen],
# [RevoluteJoint(9): j_spine],
# [WeldJoint(10): j_head],
# [WeldJoint(11): j_scapula_left],
# [EulerJoint(12): j_bicep_left],
# [RevoluteJoint(13): j_forearm_left],
# [WeldJoint(14): j_scapula_right],
# [EulerJoint(15): j_bicep_right],
# [RevoluteJoint(16): j_forearm_right],
# ---[WeldJoint(17): j_forearm_right_attach]]
        
#dofs in kima -OLD KIMA
#[[Dof(0): j_pelvis_x],
# [Dof(1): j_pelvis_y],
# [Dof(2): j_pelvis_z],
# [Dof(3): j_pelvis2_z],
# [Dof(4): j_pelvis2_y],
# [Dof(5): j_pelvis2_x],
# [Dof(6): j_thigh_left_z],             (0)
# [Dof(7): j_thigh_left_y],             (1)
# [Dof(8): j_thigh_left_x],             (2)
# [Dof(9): j_shin_left],                (3)
# [Dof(10): j_heel_left_1],             (4)
# [Dof(11): j_heel_left_2],             (5)
# [Dof(12): j_thigh_right_z],           (6)
# [Dof(13): j_thigh_right_y],           (7)
# [Dof(14): j_thigh_right_x],           (8)
# [Dof(15): j_shin_right],              (9)
# [Dof(16): j_heel_right_1],            (10)
# [Dof(17): j_heel_right_2],            (11)
# [Dof(18): j_abdomen_1],               (12)
# [Dof(19): j_abdomen_2],               (13)
# [Dof(20): j_spine],                   (14)
# [Dof(21): j_bicep_left_z],            (15)
# [Dof(22): j_bicep_left_y],            (16)
# [Dof(23): j_bicep_left_x],            (17)
# [Dof(24): j_forearm_left],            (18)
# [Dof(25): j_bicep_right_z],           (19)
# [Dof(26): j_bicep_right_y],           (20)
# [Dof(27): j_bicep_right_x],           (21)
# [Dof(28): j_forearm_right]]           (22)



#SKEL info for biped
#root orientation 0,1,2
#root location 3,4,5
#left thigh 6,7,8
#left shin, left heel(2), left toe 9,10,11,12
#right thigh ,13,14,15
#right shin, right heel(2), right toe 16,17,18,19
#abdoment(2), spine 20,21,22
#head 23,24
#scap left, bicep left(3) 25,26,27,28
#forearm left, hand left 29,30
#scap right, bicep right (3) 31,32,33,34
#forearm right.,hand right 35,36    
        #joints in biped
#[FreeJoint(0): j_pelvis]
        
#[EulerJoint(1): j_thigh_left]
#[RevoluteJoint(2): j_shin_left]
#[UniversalJoint(3): j_heel_left]
#[RevoluteJoint(4): j_toe_left]
        
#[EulerJoint(5): j_thigh_right]
#[RevoluteJoint(6): j_shin_right]
#[UniversalJoint(7): j_heel_right]
#[RevoluteJoint(8): j_toe_right]
        
#[UniversalJoint(9): j_abdomen]
#[RevoluteJoint(10): j_spine]
#[UniversalJoint(11): j_head]
        
#[RevoluteJoint(12): j_scapula_left]
#[EulerJoint(13): j_bicep_left]
#[RevoluteJoint(14): j_forearm_left]
#[RevoluteJoint(15): j_hand_left]
        
#[RevoluteJoint(16): j_scapula_right]
#[EulerJoint(17): j_bicep_right]
#[RevoluteJoint(18): j_forearm_right]
#[RevoluteJoint(19): j_hand_right]
        #dofs in biped
#[Dof(0): j_pelvis_rot_x]
#[Dof(1): j_pelvis_rot_y]
#[Dof(2): j_pelvis_rot_z]
#[Dof(3): j_pelvis_pos_x]
#[Dof(4): j_pelvis_pos_y]
#[Dof(5): j_pelvis_pos_z]
#[Dof(6): j_thigh_left_z]
#[Dof(7): j_thigh_left_y]
#[Dof(8): j_thigh_left_x]
#[Dof(9): j_shin_left]
#[Dof(10): j_heel_left_1]
#[Dof(11): j_heel_left_2]
#[Dof(12): j_toe_left]
#[Dof(13): j_thigh_right_z]
#[Dof(14): j_thigh_right_y]
#[Dof(15): j_thigh_right_x]
#[Dof(16): j_shin_right]
#[Dof(17): j_heel_right_1]
#[Dof(18): j_heel_right_2]
#[Dof(19): j_toe_right]
#[Dof(20): j_abdomen_1]
#[Dof(21): j_abdomen_2]
#[Dof(22): j_spine]
#[Dof(23): j_head_1]
#[Dof(24): j_head_2]
#[Dof(25): j_scapula_left]
#[Dof(26): j_bicep_left_z]
#[Dof(27): j_bicep_left_y]
#[Dof(28): j_bicep_left_x]
#[Dof(29): j_forearm_left]
#[Dof(30): j_hand_left]
#[Dof(31): j_scapula_right]
#[Dof(32): j_bicep_right_z]
#[Dof(33): j_bicep_right_y]
#[Dof(34): j_bicep_right_x]
#[Dof(35): j_forearm_right]
#[Dof(36): j_hand_right]